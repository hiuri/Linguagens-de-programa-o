//Questao 5 Hiuri Liberato

const prompt = require('prompt-sync')();

let f;
for(let i = -100;i <= 100;i += 5){
	f = parseFloat((9*i)/5 + 32,10);
	console.log(`Celsius: ${i}, Fahrenheit: ${f}`);
} 

