const prompt = require('prompt-sync')(); //funcao para realizar leitura

function gameOver(){
	if(){
}

function mainLoop(){
	let 


}
