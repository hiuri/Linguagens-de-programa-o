#include<stdio.h>

int main(){
    int i=0;
    printf("OLA MUNDO\n");
    return 0;
}