//Questao 3

const prompt = require('prompt-sync')();


console.log("Digite tres notas separadas por quebra de linha");
let n1 = parseInt(prompt());
let n2 = parseInt(prompt());
let n3 = parseInt(prompt());
let media = parseInt((n1+n2+n3)/3,10);

console.log(`Media ${media}`);
if(media>=7){
  console.log("Aprovado");
}else if(media>=5){
  console.log("Recuperacao");
}else{
  console.log("Reprovado");
}

