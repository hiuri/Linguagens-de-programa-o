//Codigo sobre Heranca
class ContaCorrente{
	constructor(){
		this.saldo = 0;
	}
	getSaldo(x){
		if(this.saldo>=x){
			this.saldo = this.saldo - x;
			return x;
		}else{
			console.log("Saldo insuficiente");
		}
	}
	setSaldo(x){
		this.saldo = x;
	}

}

conta1 = new ContaCorrente();
conta1.setSaldo(500);
conta1.getSaldo(501);

class ContaEspecial extends ContaCorrente{
	getSaldo(x){
			if(this.saldo>=x){
				this.saldo = this.saldo - x;
				return x;
			}else{
				console.log("Saldo negativado");
				this.saldo = this.saldo - x;
				this.saldo = this.saldo - (this.saldo*(1/100));
				return x;
			}
		}
}

conta2 = new ContaEspecial();
conta2.setSaldo(500);
conta2.getSaldo(501);
