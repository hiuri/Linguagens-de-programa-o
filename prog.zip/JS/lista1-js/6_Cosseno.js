//Questao 6 Hiuri Liberato


//Nao terminei essa
const prompt = require('prompt-sync')();


function fatorial(num){
	let numero = parseInt(num,10);
    let resultado=1;
    let count=1;

    while(count<=numero){
    	resultado *= count;
    	count++;
    	//console.log("ENTROU");
  }
  return resultado;
}


let x = parseInt(prompt(),10);
let cos = 1;
let fat;
controle = true;

for(let i=2;i<=40;i+2){
	if(controle == true){
		fat = parseInt(fatorial(i),10);
		cos = cos - parseInt(Math.pow(x)/fat,10);
		controle = false;
	}else{
		fat = parseInt(fatorial(i),10);
		cos = cos + parseInt(Math.pow(x)/fat,10);
		controle = true;	
	}
}

console.log(`${cos}`);
