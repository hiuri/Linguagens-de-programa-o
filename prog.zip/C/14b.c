#include <stdio.h>
//boa pratica inicializar as variáveis

void bubble_sort (int vetor[], int n) {
	printf("entrou");
    int k, j, aux;
    for (k = n - 1; k > 0; k--) {
		for (j = 0; j < k; j++) {
            if (vetor[j] > vetor[j + 1]) {
                aux          = vetor[j];
                vetor[j]     = vetor[j + 1];
                vetor[j + 1] = aux;
            }
        }
    }
}


int main(void) {
  int N=0,i=0;//numero de casos de teste
  int entrada=0;
  int pinturas[1000];
  scanf("%d",&N);
  while(N!=0){
    while(N>i){
      scanf("%d", &pinturas[i]);
      i++;
    }
    scanf("%d",&N);
    i=0;
  }
  bubble_sort(pinturas,N);
  printf("%d",pinturas[0]);
  return 0;
}
