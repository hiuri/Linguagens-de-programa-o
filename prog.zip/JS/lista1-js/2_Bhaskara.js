//Questao 2 Hiuri Liberato

const prompt = require('prompt-sync')();


let a, b, c, x1, x2;

a = parseInt(prompt());
b = parseInt(prompt());
c = parseInt(prompt());

let delta = parseFloat((b * b) - 4 * a * c,10);

if(delta < 0){
	console.log("Para Delta negativo, não existem raízes reais.\n");  
}else{
	x1 = parseFloat((-1*b + Math.sqrt(delta))/(2*a),10);
	x2 = parseFloat((-1*b - Math.sqrt(delta))/(2*a),10);
	console.log(`Raizes x1 = ${x1}, x2 = ${x2}`);
}
