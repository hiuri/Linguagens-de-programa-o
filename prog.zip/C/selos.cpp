#include <iostream>
#include <map>
#include <vector>

using namespace std;

int main ()
{

  //declaracao de variaveis
  int qtd_testes, qtd_amigos, qtd_selos,aux;
  map <int, vector<int>> mapa_selos;
  //quantidade de testes
  cout << "Digite a qtd de testes\n";
  cin >> qtd_testes;


  //Leitura da entrada
  for(int i=0;i<qtd_testes; i++){//loop de testes
    cout << "Digite a qtd de amigos\n";
    cin >> qtd_amigos;
    for(int j=0;j<qtd_amigos;j++){//loop de amigos
      cout << "Digite a qtd de selos\n";
      cin >> qtd_selos;
      vector<int> vector_aux;
      for(int k=0;k<qtd_selos;k++){//loop de selos
        cin >> aux;
        vector_aux.push_back(aux);
      }
      //mapa_selos.insert({vector_aux,j});//inserindo vetores no mapa
      mapa_selos[j] = vector_aux;//inserindo vetores no mapa
    }


  }//Fim da leitura da entrada
  cout << "Fim da leitura\n";



  //Conferindo as repetidas
  int i = qtd_amigos;
  int k = qtd_amigos-1;
  int flag = 0;//marcar quando achou selo repetido
  while(i--){
    for(int j=0;j<mapa_selos[i].size();j++){
      //cout << mapa_selos[i][j] << "\n";//primeiro elemento da comparacao
      while(k--){
        for(int l=0;l<mapa_selos[k].size();l++){
          if(mapa_selos[i][j] == mapa_selos[k][l]){
            auto elem_to_remove = mapa_selos[k].begin()+l;
            mapa_selos[k].erase(elem_to_remove);
          }
        }
      }
    }
  }
  return 0;
}