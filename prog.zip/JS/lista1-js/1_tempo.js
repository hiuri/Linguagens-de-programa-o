//Questao 1 Hiuri Liberato

const prompt = require('prompt-sync')();

let tempo = prompt("Digite o tempo em segundos.");
let segundos;
let minutos = parseInt(tempo/60, 10);
let horas = parseInt(minutos/60, 10);
minutos = minutos%60
segundos = tempo%60;
console.log(`${horas}horas, ${minutos}minutos, e ${segundos}segundos.`);
