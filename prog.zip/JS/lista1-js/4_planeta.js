//Questao 4 Hiuri Liberato

const prompt = require('prompt-sync')();

let peso = parseInt(prompt(),10);
let planeta = parseInt(prompt(),10);

switch (planeta){
	case 1:
		peso = parseFloat(peso*0.37,10);
		console.log(`${peso}`);
		break;
	case 2:
		peso = parseFloat(peso*0.88,10);
		console.log(`${peso}`);
		break;
	case 3:
		peso = parseFloat(peso*0.38,10);
		console.log(`${peso}`);
		break;
	case 4:
		peso = parseFloat(peso*2.64,10);
		console.log(`${peso}`);
		break;
	case 5:
		peso = parseFloat(peso*1.15,10);
		console.log(`${peso}`);
		break;
	case 6:
		peso = parseFloat(peso*1.17,10);
		console.log(`${peso}`);
		break;
	case 7:
		peso = parseFloat(peso*1.18,10);
		console.log(`${peso}`);
		break;
}
